package auto.system.gardencontroller;

public enum Events {
	Rainfall,Snowfall

}
