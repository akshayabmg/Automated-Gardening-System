package auto.system.gardencontroller;

import java.util.Date;

public class Garden_Constants {
public static final int Duration_Day_In_Millis=1440000;
public static final int Control_Systems_Delay=10000;
public static final String FileName_Plant="logs_plant.txt";
public static final String FileName_System="logs_system.txt";
public static final String FileName_errors = "errorfile.txt";

}
