package auto.system.gardenflowers;

public enum FlowerStage {
		Stage1_Seed,Stage2_Sapling,Stage3_Flower,Stage4_Flowered	
}
